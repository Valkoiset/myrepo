Each notebook was run with Julia `1.0.2` kernel.
Flux library was pinned to version `v0.6.9`.